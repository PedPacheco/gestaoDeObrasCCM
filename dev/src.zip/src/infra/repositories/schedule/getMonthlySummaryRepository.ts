import moment from 'moment';
import { PrismaService } from 'src/infra/prisma/prisma.service';
import { GetMonthlySummaryDTO } from 'src/interface/dtos/scheduleDTO';
import { GetMonthlySummaryInterface } from 'src/interface/types/schedule/monthlySummaryInterface';

import { Injectable } from '@nestjs/common';

import { IGetMonthlySummaryRepository } from '../../../domain/repositories/schedule/IGetMonthlySummaryRepository';

@Injectable()
export class GetMonthlySummaryRepository implements IGetMonthlySummaryRepository {
  constructor(private readonly prisma: PrismaService) {}

  async getSummary(
    filters: GetMonthlySummaryDTO,
  ): Promise<GetMonthlySummaryInterface[]> {
    const { dataFinal, dataInicial, idRegional, idParceira, idTipo, idGrupo } =
      filters;

    return await this.prisma.programacoes.findMany({
      where: {
        id_status_programacao: { not: 7 },
        data_prog: {
          gte: moment.utc(dataInicial, 'DD/MM/YYYY').toDate(),
          lte: moment.utc(dataFinal, 'DD/MM/YYYY').toDate(),
        },
        obras: {
          tipos: {
            id_grupo:
              idGrupo && idGrupo.length > 0 ? { in: idGrupo } : undefined,
          },
          municipios: {
            id_regional:
              idRegional && idRegional.length > 0
                ? { in: idRegional }
                : undefined,
          },
          id_turma:
            idParceira && idParceira.length > 0
              ? { in: idParceira }
              : undefined,
          id_tipo: idTipo && idTipo.length > 0 ? { in: idTipo } : undefined,
        },
      },
      select: {
        data_prog: true,
        prog: true,
        exec: true,
        equipe_linha_viva: true,
        equipe_linha_morta: true,
        equipe_regularizacao: true,
        obras: {
          select: {
            ovnota: true,
            ordem_dci: true,
            ordem_dca: true,
            ordem_dcd: true,
            ordem_dcim: true,
            mo_planejada: true,
            mo_pend: true,
            executado: true,
            turmas: { select: { turma: true } },
            tipos: { select: { grupos: { select: { grupo: true } } } },
          },
        },
      },
      orderBy: { data_prog: 'asc' },
    });
  }
}
