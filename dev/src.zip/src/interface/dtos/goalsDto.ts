import { Transform, Type } from 'class-transformer';
import { IsArray, IsBoolean, IsNumber, IsOptional } from 'class-validator';
import { convertParameterValue } from 'src/utils/convertParameterValue';

export class GoalsDTO {
  @IsOptional()
  @IsBoolean()
  insufficientPermission?: boolean;

  @IsOptional()
  @IsArray()
  @Transform(({ value }) => convertParameterValue(value))
  tipo?: number[];

  @IsOptional()
  @IsArray()
  @Transform(({ value }) => convertParameterValue(value))
  regional?: number[];

  @IsOptional()
  @IsArray()
  @Transform(({ value }) => convertParameterValue(value))
  parceira?: number[];

  @IsArray()
  @Transform(({ value }) => convertParameterValue(value))
  ano?: number[];

  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  anoPlan?: number;

  @IsOptional()
  @IsArray()
  @Transform(({ value }) => convertParameterValue(value))
  empreendimento?: number[];

  @IsBoolean()
  @Transform(({ value }) => (value === 'true' ? true : false))
  btzero?: boolean;

  @IsBoolean()
  @Transform(({ value }) => (value === 'true' ? true : false))
  rda?: boolean;
}
